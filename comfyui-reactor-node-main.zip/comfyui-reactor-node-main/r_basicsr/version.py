# GENERATED VERSION FILE
# TIME: Wed Apr  5 00:20:48 2023
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
